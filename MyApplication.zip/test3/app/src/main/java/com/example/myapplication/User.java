package com.example.myapplication;

public class User {
    private int id;
    private String email;
    private String password;
    private int progressPoints;

    public User() {}

    public User(String email, String password) {
        this.email = email;
        this.password = password;
        this.progressPoints = 0;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public int getProgressPoints() { return progressPoints; }
    public void setProgressPoints(int progressPoints) { this.progressPoints = progressPoints; }
}