package com.example.myapplication;

public class Lesson {
    private int id;
    private String title;
    private String description;
    private String content;
    private int iconResId;
    private boolean isCompleted;
    private int score;
    private String difficulty;

    public Lesson() {
        // Default constructor
    }
    // Add this new constructor to your Lesson class
    public Lesson(String title, String description, int iconResId) {
        this.title = title;
        this.description = description;
        this.iconResId = iconResId;
        this.isCompleted = false;
        this.score = 0;
    }
    public Lesson(int id, String title, String description, String content, int iconResId) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.content = content;
        this.iconResId = iconResId;
        this.isCompleted = false;
        this.score = 0;
    }

    public Lesson(int id, String title, String description, String content, int iconResId, String difficulty) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.content = content;
        this.iconResId = iconResId;
        this.difficulty = difficulty;
        this.isCompleted = false;
        this.score = 0;
    }


    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    /**
     * Sets the lesson title with validation
     * @param title The title to set (1-100 characters)
     * @throws IllegalArgumentException if title is null, empty, or too long
     */
    public void setTitle(String title) {
        if (title == null) {
            throw new IllegalArgumentException("Title cannot be null");
        }

        title = title.trim();

        if (title.isEmpty()) {
            throw new IllegalArgumentException("Title cannot be empty");
        }

        if (title.length() > 100) {
            throw new IllegalArgumentException("Title cannot exceed 100 characters");
        }

        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getIconResId() {
        return iconResId;
    }

    public void setIconResId(int iconResId) {
        this.iconResId = iconResId;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    // Utility method to get completion status as string
    public String getCompletionStatus() {
        return isCompleted ? "Completed" : "Not Completed";
    }

    // Method to calculate percentage score
    public int getPercentageScore(int totalQuestions) {
        if (totalQuestions == 0) return 0;
        return (score * 100) / totalQuestions;
    }
}