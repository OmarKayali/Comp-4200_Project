package com.example.myapplication;

public class Question {
    private int id;
    private int lessonId;
    private String text;
    private boolean correctAnswer;
    private String questionType; // "TF" for True/False, "MCQ" for multiple choice
    private String explanation;
    private int difficulty; // 1-5 scale
    private boolean userAnswer;
    private boolean isAnswered;

    public Question() {
        // Default constructor
    }

    public Question(int id, int lessonId, String text, boolean correctAnswer) {
        this(id, lessonId, text, correctAnswer, "TF", "", 1);
    }

    public Question(int id, int lessonId, String text, boolean correctAnswer,
                    String questionType, String explanation, int difficulty) {
        this.id = id;
        this.lessonId = lessonId;
        this.text = text;
        this.correctAnswer = correctAnswer;
        this.questionType = questionType;
        this.explanation = explanation;
        this.difficulty = difficulty;
        this.isAnswered = false;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLessonId() {
        return lessonId;
    }

    public void setLessonId(int lessonId) {
        this.lessonId = lessonId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public boolean isCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(boolean correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public String getQuestionType() {
        return questionType;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public boolean getUserAnswer() {
        return userAnswer;
    }

    public void setUserAnswer(boolean userAnswer) {
        this.userAnswer = userAnswer;
        this.isAnswered = true;
    }

    public boolean isAnswered() {
        return isAnswered;
    }

    public void setAnswered(boolean answered) {
        isAnswered = answered;
    }

    // Utility methods
    public boolean isUserCorrect() {
        return isAnswered && (userAnswer == correctAnswer);
    }

    public String getCorrectAnswerString() {
        return correctAnswer ? "True" : "False";
    }

    public String getUserAnswerString() {
        return isAnswered ? (userAnswer ? "True" : "False") : "Not answered";
    }

    public int getPointsValue() {
        return difficulty * 10; // More points for harder questions
    }
}