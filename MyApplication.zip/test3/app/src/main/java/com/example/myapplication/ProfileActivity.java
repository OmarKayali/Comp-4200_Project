package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ProfileActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private String currentUserEmail;
    private EditText etEmail, etCurrentPassword, etNewPassword, etConfirmPassword;
    private TextView tvProgressPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Get current user email from intent or preferences
        currentUserEmail = getIntent().getStringExtra("USER_EMAIL");
        if (currentUserEmail == null || currentUserEmail.equals("guest")) {
            finish(); // Shouldn't be here as guest
            return;
        }

        // Initialize views
        initViews();

        // Load user data
        loadUserData();

        // Setup button listeners
        setupButtonListeners();
    }

    private void initViews() {
        // Toolbar setup
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("My Profile");
        }

        // Input fields
        etEmail = findViewById(R.id.etEmail);
        etCurrentPassword = findViewById(R.id.etCurrentPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        tvProgressPoints = findViewById(R.id.tvProgressPoints);

        // Buttons
        Button btnSaveChanges = findViewById(R.id.btnSaveChanges);
        Button btnDeleteAccount = findViewById(R.id.btnDeleteAccount);
        Button btnLogout = findViewById(R.id.btnLogout);
    }

    private void loadUserData() {
        User user = databaseHelper.getUser(currentUserEmail);
        if (user != null) {
            etEmail.setText(user.getEmail());
            tvProgressPoints.setText(String.format("Progress Points: %d", user.getProgressPoints()));
        }
    }

    private void setupButtonListeners() {
        // Save Changes Button
        findViewById(R.id.btnSaveChanges).setOnClickListener(v -> updateAccount());

        // Delete Account Button
        findViewById(R.id.btnDeleteAccount).setOnClickListener(v -> showDeleteConfirmation());

        // Logout Button
        findViewById(R.id.btnLogout).setOnClickListener(v -> logoutUser());
    }

    private void updateAccount() {
        String newEmail = etEmail.getText().toString().trim();
        String currentPassword = etCurrentPassword.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        // Validate inputs
        if (newEmail.isEmpty()) {
            etEmail.setError("Email cannot be empty");
            return;
        }

        // Check if password fields are filled when changing password
        boolean changingPassword = !newPassword.isEmpty() || !confirmPassword.isEmpty();
        if (changingPassword) {
            if (currentPassword.isEmpty()) {
                etCurrentPassword.setError("Enter current password");
                return;
            }
            if (newPassword.isEmpty()) {
                etNewPassword.setError("Enter new password");
                return;
            }
            if (!newPassword.equals(confirmPassword)) {
                etConfirmPassword.setError("Passwords don't match");
                return;
            }
        }

        // Verify current credentials
        if (!databaseHelper.checkUserCredentials(currentUserEmail, currentPassword)) {
            etCurrentPassword.setError("Incorrect password");
            return;
        }

        // Check if email is being changed to an existing one
        if (!newEmail.equalsIgnoreCase(currentUserEmail)){
            if (databaseHelper.checkEmail(newEmail)) {
                etEmail.setError("Email already in use");
                return;
            }
        }

        // Update credentials
        boolean success = databaseHelper.updateUserCredentials(
                currentUserEmail,
                newEmail,
                changingPassword ? newPassword : currentPassword
        );

        if (success) {
            // Update current session if email changed
            if (!newEmail.equalsIgnoreCase(currentUserEmail)) {
                SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
                prefs.edit().putString("email", newEmail).apply();
                currentUserEmail = newEmail;
            }

            Toast.makeText(this, "Account updated successfully", Toast.LENGTH_SHORT).show();
            clearPasswordFields();
        } else {
            Toast.makeText(this, "Failed to update account", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Delete Account")
                .setMessage("Are you sure you want to delete your account? All your data will be lost.")
                .setPositiveButton("Delete", (dialog, which) -> deleteAccount())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteAccount() {
        boolean deleted = databaseHelper.deleteUser(currentUserEmail);
        if (deleted) {
            // Clear session and return to login
            SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
            prefs.edit().clear().apply();

            Toast.makeText(this, "Account deleted", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finishAffinity(); // Close all activities
        } else {
            Toast.makeText(this, "Failed to delete account", Toast.LENGTH_SHORT).show();
        }
    }

    private void logoutUser() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        prefs.edit()
                .putBoolean("is_logged_in", false)
                .putBoolean("remember_me", false)
                .apply();

        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void clearPasswordFields() {
        etCurrentPassword.setText("");
        etNewPassword.setText("");
        etConfirmPassword.setText("");
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}