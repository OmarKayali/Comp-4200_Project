package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.ViewModelProvider;
import java.util.List;

public class LessonDetailActivity extends AppCompatActivity {
    private LessonViewModel viewModel;
    private int userId, lessonId;
    private TextView tvTitle, tvDescription, tvContent, tvQuizResult, tvProgressText;
    private ProgressBar progressHeaderBar, quizProgressBar;
    private CardView quizCard;
    private Button btnTrue, btnFalse, btnTryIt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson_detail);

        // Initialize Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Initialize Views
        initViews();

        // Get IDs
        userId = getCurrentUserId();
        lessonId = getIntent().getIntExtra("lesson_id", -1);
        if (lessonId == -1) {
            Toast.makeText(this, "Invalid lesson", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Setup ViewModel
        viewModel = new ViewModelProvider(this).get(LessonViewModel.class);

        // Load lesson data
        loadLessonData();
    }

    private void initViews() {
        tvTitle = findViewById(R.id.tvLessonTitle);
        tvDescription = findViewById(R.id.tvLessonDescription);
        tvContent = findViewById(R.id.tvLessonContent);
        tvQuizResult = findViewById(R.id.tvQuizResult);
        tvProgressText = findViewById(R.id.tvProgressText);
        progressHeaderBar = findViewById(R.id.progressHeaderBar);
        quizProgressBar = findViewById(R.id.progressBar);
        quizCard = findViewById(R.id.quizCard);
        btnTrue = findViewById(R.id.btnTrue);
        btnFalse = findViewById(R.id.btnFalse);
        btnTryIt = findViewById(R.id.btnTryIt);

        // Set button texts from strings.xml
        btnTrue.setText(R.string.true_text);
        btnFalse.setText(R.string.false_text);
    }

    private int getCurrentUserId() {
        return getSharedPreferences("user_prefs", MODE_PRIVATE)
                .getInt("user_id", 1);
    }

    // In LessonDetailActivity.java
    private void loadLessonData() {
        Log.d("LessonDetail", "Loading lesson ID: " + lessonId);
        viewModel.getLesson(lessonId).observe(this, lesson -> {
            if (lesson != null) {
                Log.d("LessonDetail", "Loaded lesson: " + lesson.getTitle());
                updateLessonUI(lesson);
                loadQuizQuestions();
                updateProgressUI();
            } else {
                String error = "Lesson " + lessonId + " not found in database";
                Log.e("LessonDetail", error);
                showError(error);

                // Debug: Print all available lessons
                List<Lesson> allLessons = new DatabaseHelper(this).getAllLessons();
                Log.d("LessonDetail", "Available lessons: " + allLessons.size());
                for (Lesson l : allLessons) {
                    Log.d("LessonDetail", l.getId() + ": " + l.getTitle());
                }
            }
        });
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        // Optionally show a retry button
    }

    private void updateLessonUI(Lesson lesson) {
        tvTitle.setText(lesson.getTitle());
        tvDescription.setText(lesson.getDescription());
        tvContent.setText(lesson.getContent());
        getSupportActionBar().setTitle(lesson.getTitle());
    }

    private void updateProgressUI() {
        viewModel.getLessonProgress(userId, lessonId).observe(this, progress -> {
            progressHeaderBar.setProgress(progress);
            tvProgressText.setText(String.format("%d%%", progress));
        });
    }

    private void loadQuizQuestions() {
        viewModel.getQuestionsForLesson(lessonId).observe(this, questions -> {
            if (questions != null && !questions.isEmpty()) {
                setupQuiz(questions);
            } else {
                quizCard.setVisibility(View.GONE);
            }
        });
    }

    private void setupQuiz(List<Question> questions) {
        quizCard.setVisibility(View.VISIBLE);
        int[] currentQuestion = {0};
        int[] score = {0};

        quizProgressBar.setMax(questions.size());
        showQuestion(questions.get(0));

        btnTrue.setOnClickListener(v -> checkAnswer(true, questions, currentQuestion, score));
        btnFalse.setOnClickListener(v -> checkAnswer(false, questions, currentQuestion, score));
    }

    private void showQuestion(Question question) {
        TextView tvQuestion = findViewById(R.id.tvQuestion);
        tvQuestion.setText(question.getText());
    }

    private void checkAnswer(boolean userAnswer, List<Question> questions,
                             int[] currentQuestion, int[] score) {
        boolean isCorrect = (userAnswer == questions.get(currentQuestion[0]).isCorrectAnswer());

        if (isCorrect) {
            score[0]++;
            Toast.makeText(this,
                    getString(R.string.correct_answer, 10),
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this,
                    R.string.wrong_answer,
                    Toast.LENGTH_SHORT).show();
        }

        currentQuestion[0]++;
        quizProgressBar.setProgress(currentQuestion[0]);

        if (currentQuestion[0] < questions.size()) {
            showQuestion(questions.get(currentQuestion[0]));
        } else {
            finishQuiz(score[0], questions.size());
        }
    }

    private void finishQuiz(int score, int totalQuestions) {
        int points = score * 10;
        viewModel.updateUserProgress(userId, lessonId, points).observe(this, success -> {
            String result = String.format(getString(R.string.lesson_complete),
                    score, totalQuestions);
            tvQuizResult.setText(result);
            tvQuizResult.setVisibility(View.VISIBLE);
            btnTrue.setEnabled(false);
            btnFalse.setEnabled(false);

            // Show "Try It" button after quiz completion
            btnTryIt.setVisibility(View.VISIBLE);
            btnTryIt.setOnClickListener(v -> launchPracticeActivity());
        });
    }

    private void launchPracticeActivity() {
        Intent intent = new Intent(this, LessonDetailActivity.class);
        intent.putExtra("lesson_id", 1); // Hardcode to test with lesson ID 1
        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}