package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);
        prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);

        // Check for remembered login first
        if (prefs.getBoolean("remember_me", false) && prefs.getBoolean("is_logged_in", false)) {
            String savedEmail = prefs.getString("email", null);
            if (savedEmail != null && !savedEmail.equals("guest")) {
                navigateToMain(savedEmail);
                return;
            }
        }

        setupUI();
    }

    private void setupUI() {
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        CheckBox cbRemember = findViewById(R.id.cbStayLoggedIn);

        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (validateCredentials(email, password)) {
                saveLoginState(cbRemember.isChecked(), true, email);
                navigateToMain(email);
            }
        });

        findViewById(R.id.btnSkip).setOnClickListener(v -> {
            saveLoginState(false, true, "guest");
            navigateToMain("guest");
        });

        findViewById(R.id.btnRegister).setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (validateRegistration(email, password)) {
                User user = new User(email, password);
                if (databaseHelper.addUser(user)) {
                    saveLoginState(true, true, email);
                    navigateToMain(email);
                    Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Registration failed. Email may already exist.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateCredentials(String email, String password) {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!databaseHelper.checkUserCredentials(email, password)) {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean validateRegistration(String email, String password) {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (databaseHelper.checkEmail(email)) {
            Toast.makeText(this, "Email already exists", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void saveLoginState(boolean remember, boolean isLoggedIn, String email) {
        prefs.edit()
                .putBoolean("is_logged_in", isLoggedIn)
                .putBoolean("remember_me", remember)
                .putString("email", email)
                .apply();
    }

    private void navigateToMain(String email) {
        startActivity(new Intent(this, MainActivity.class)
                .putExtra("USER_EMAIL", email));
        finish();
    }
}