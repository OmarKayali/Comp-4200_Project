package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class PracticeActivity extends AppCompatActivity {

    private EditText codeEditor;
    private FrameLayout previewContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practice);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Initialize views
        codeEditor = findViewById(R.id.etCodeEditor);
        previewContainer = findViewById(R.id.previewContainer);
        Button btnRun = findViewById(R.id.btnRunCode);

        // Update preview when button clicked
        btnRun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePreview();
            }
        });
    }

    private void updatePreview() {
        // Clear previous preview
        previewContainer.removeAllViews();

        try {
            // Inflate the XML code from editor
            View preview = View.inflate(this, R.layout.dynamic_preview, null);
            previewContainer.addView(preview);

        } catch (Exception e) {
            Toast.makeText(this, "Error in code syntax", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}