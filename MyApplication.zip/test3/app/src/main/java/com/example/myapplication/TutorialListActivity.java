package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class TutorialListActivity extends AppCompatActivity
        implements LessonAdapter.OnLessonClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial_list);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.lessons_title);
        }

        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvTutorials);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create sample data using the new constructor
        List<Lesson> lessons = new ArrayList<>();
        lessons.add(new Lesson(
                getString(R.string.lesson_1_title),
                getString(R.string.lesson_1_desc),
                R.drawable.ic_layout
        ));
        lessons.add(new Lesson(
                getString(R.string.lesson_2_title),
                getString(R.string.lesson_2_desc),
                R.drawable.ic_button
        ));
        lessons.add(new Lesson(
                getString(R.string.lesson_3_title),
                getString(R.string.lesson_3_desc),
                R.drawable.ic_text
        ));

        // Set adapter
        LessonAdapter adapter = new LessonAdapter(lessons, this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onLessonClick(Lesson lesson) {
        Intent intent = new Intent(this, LessonDetailActivity.class);
        intent.putExtra("lesson_id", lesson.getId()); // Pass the lesson ID
        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}