package com.example.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class TutorialListActivity extends AppCompatActivity
        implements LessonAdapter.OnLessonClickListener {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial_list);

        databaseHelper = new DatabaseHelper(this);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.lessons_title);
        }

        setupRecyclerView();
    }

    private void setupRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.rvTutorials);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Get writable database instance
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        // 1. Get lessons from database
        List<Lesson> lessons = databaseHelper.getAllLessons();

        // 2. If empty, insert default lessons
        if (lessons.isEmpty()) {
            Toast.makeText(this, "Inserting default lessons...", Toast.LENGTH_SHORT).show();

            // Start transaction for atomic operations
            db.beginTransaction();
            try {
                databaseHelper.initializeDefaultData(db);
                db.setTransactionSuccessful();

                // Refresh the lessons list
                lessons = databaseHelper.getAllLessons();
            } finally {
                db.endTransaction();
            }
        }

        // 3. Debug log
        Log.d("Lessons", "Found " + lessons.size() + " lessons");
        for (Lesson l : lessons) {
            Log.d("Lesson", "ID: " + l.getId() + " | Title: " + l.getTitle());
        }

        // 4. Setup adapter
        LessonAdapter adapter = new LessonAdapter(lessons, this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onLessonClick(Lesson lesson) {
        Log.d("LessonClick", "Opening lesson ID: " + lesson.getId());

        Intent intent = new Intent(this, LessonDetailActivity.class);
        intent.putExtra("lesson_id", lesson.getId());
        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}