package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "LearningApp.db";
    private static final int DATABASE_VERSION = 4; // Incremented version for new columns

    // Table and column constants
    private static final String TABLE_USERS = "users";
    private static final String TABLE_LESSONS = "lessons";
    private static final String TABLE_QUESTIONS = "questions";
    private static final String TABLE_PROGRESS = "user_progress";

    // Common columns
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_LESSON_ID = "lesson_id";
    private static final String COLUMN_QUESTION_ID = "question_id";

    // Users table columns
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_PROGRESS = "progress_points";
    private static final String COLUMN_LAST_LOGIN = "last_login";

    // Lessons table columns
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_CONTENT = "content";
    private static final String COLUMN_ICON_RES = "icon_res";
    private static final String COLUMN_DIFFICULTY = "difficulty";

    // Questions table columns
    private static final String COLUMN_QUESTION_TEXT = "question_text";
    private static final String COLUMN_CORRECT_ANSWER = "correct_answer";
    private static final String COLUMN_QUESTION_TYPE = "question_type";

    // Progress table columns
    private static final String COLUMN_IS_CORRECT = "is_correct";
    private static final String COLUMN_IS_COMPLETED = "is_completed";
    private static final String COLUMN_TIMESTAMP = "timestamp";
    private static final String COLUMN_COMPLETION_DATE = "completion_date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createUsersTable(db);
        createLessonsTable(db);
        Log.d("DatabaseHelper", "Lessons table created"); // Add this line

        createQuestionsTable(db);
        createProgressTable(db);
        initializeDefaultData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 4) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_LESSONS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTIONS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROGRESS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            onCreate(db);
            return; // Skip other migrations since we rebuilt everything
        }

        if (oldVersion < 2) {
            // Migration for version 1 to 2
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COLUMN_LAST_LOGIN + " DATETIME");
        }
        if (oldVersion < 3) {
            // Migration for version 2 to 3
            db.execSQL("ALTER TABLE " + TABLE_LESSONS + " ADD COLUMN " + COLUMN_ICON_RES + " INTEGER DEFAULT 0");

            // Fix for the user_id -> id column rename if needed
            try {
                db.execSQL("ALTER TABLE " + TABLE_USERS + " RENAME COLUMN user_id TO " + COLUMN_ID);
            } catch (Exception e) {
                Log.w("DatabaseHelper", "Column rename may have already been done", e);
            }
        }
        if (oldVersion < 4) {
            // Migration for version 3 to 4
            db.execSQL("ALTER TABLE " + TABLE_PROGRESS + " ADD COLUMN " + COLUMN_IS_COMPLETED + " INTEGER DEFAULT 0");
            db.execSQL("ALTER TABLE " + TABLE_PROGRESS + " ADD COLUMN " + COLUMN_COMPLETION_DATE + " DATETIME");
        }
    }

    private void createUsersTable(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_USERS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_EMAIL + " TEXT UNIQUE," +
                COLUMN_PASSWORD + " TEXT," +
                COLUMN_PROGRESS + " INTEGER DEFAULT 0)";
        db.execSQL(sql);
    }

    private void createLessonsTable(SQLiteDatabase db) {
        String CREATE_LESSONS_TABLE = "CREATE TABLE " + TABLE_LESSONS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_CONTENT + " TEXT,"
                + COLUMN_ICON_RES + " INTEGER,"
                + COLUMN_DIFFICULTY + " TEXT)";
        db.execSQL(CREATE_LESSONS_TABLE);
    }

    private void createQuestionsTable(SQLiteDatabase db) {
        String CREATE_QUESTIONS_TABLE = "CREATE TABLE " + TABLE_QUESTIONS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_LESSON_ID + " INTEGER,"
                + COLUMN_QUESTION_TEXT + " TEXT,"
                + COLUMN_CORRECT_ANSWER + " INTEGER,"
                + COLUMN_QUESTION_TYPE + " TEXT DEFAULT 'TF',"
                + "FOREIGN KEY(" + COLUMN_LESSON_ID + ") REFERENCES "
                + TABLE_LESSONS + "(" + COLUMN_ID + "))";
        db.execSQL(CREATE_QUESTIONS_TABLE);
    }

    private void createProgressTable(SQLiteDatabase db) {
        String CREATE_PROGRESS_TABLE = "CREATE TABLE " + TABLE_PROGRESS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_ID + " INTEGER,"
                + COLUMN_LESSON_ID + " INTEGER,"
                + COLUMN_QUESTION_ID + " INTEGER,"
                + COLUMN_IS_CORRECT + " INTEGER,"
                + COLUMN_IS_COMPLETED + " INTEGER DEFAULT 0,"
                + COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP,"
                + COLUMN_COMPLETION_DATE + " DATETIME,"
                + "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES "
                + TABLE_USERS + "(" + COLUMN_ID + "),"
                + "FOREIGN KEY(" + COLUMN_QUESTION_ID + ") REFERENCES "
                + TABLE_QUESTIONS + "(" + COLUMN_ID + "))";
        db.execSQL(CREATE_PROGRESS_TABLE);
    }

    // ========== User Methods ========== //
    public boolean addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, user.getEmail());
        values.put(COLUMN_PASSWORD, user.getPassword());
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // Returns true if insertion was successful
    }

    public User getUser(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID, COLUMN_EMAIL, COLUMN_PASSWORD, COLUMN_PROGRESS},
                COLUMN_EMAIL + " = ?",
                new String[]{email},
                null, null, null);

        User user = null;
        if (cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getInt(0));
            user.setEmail(cursor.getString(1));
            user.setPassword(cursor.getString(2));
            user.setProgressPoints(cursor.getInt(3));
        }
        cursor.close();
        return user;
    }

    // ========== Lesson Methods ========== //
    // ========== Lesson Methods ========== //
    public Lesson getLesson(int lessonId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        Lesson lesson = null;

        try {
            cursor = db.query(TABLE_LESSONS,
                    new String[]{COLUMN_ID, COLUMN_TITLE, COLUMN_DESCRIPTION,
                            COLUMN_CONTENT, COLUMN_ICON_RES, COLUMN_DIFFICULTY},
                    COLUMN_ID + " = ?",
                    new String[]{String.valueOf(lessonId)},
                    null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                lesson = new Lesson();

                // Get column indices first
                int idIndex = cursor.getColumnIndex(COLUMN_ID);
                int titleIndex = cursor.getColumnIndex(COLUMN_TITLE);
                int descIndex = cursor.getColumnIndex(COLUMN_DESCRIPTION);
                int contentIndex = cursor.getColumnIndex(COLUMN_CONTENT);
                int iconIndex = cursor.getColumnIndex(COLUMN_ICON_RES);
                int difficultyIndex = cursor.getColumnIndex(COLUMN_DIFFICULTY);

                // Only set values if columns exist (-1 means column not found)
                if (idIndex != -1) lesson.setId(cursor.getInt(idIndex));
                if (titleIndex != -1) lesson.setTitle(cursor.getString(titleIndex));
                if (descIndex != -1) lesson.setDescription(cursor.getString(descIndex));
                if (contentIndex != -1) lesson.setContent(cursor.getString(contentIndex));
                if (iconIndex != -1) lesson.setIconResId(cursor.getInt(iconIndex));
                if (difficultyIndex != -1) lesson.setDifficulty(cursor.getString(difficultyIndex));
            }
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error getting lesson", e);
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return lesson;
    }


    // ========== Progress Tracking Methods ========== //
    public boolean recordQuestionAnswer(int userId, int lessonId, int questionId, boolean isCorrect) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_LESSON_ID, lessonId);
        values.put(COLUMN_QUESTION_ID, questionId);
        values.put(COLUMN_IS_CORRECT, isCorrect ? 1 : 0);

        long result = db.insert(TABLE_PROGRESS, null, values);

        if (result != -1 && isCorrect) {
            updateUserProgress(userId, lessonId, 10); // 10 points per correct answer

            // Check if lesson should be marked complete
            int totalQuestions = getQuestionsForLesson(lessonId).size();
            int correctAnswers = getLessonScore(userId, lessonId);

            if (correctAnswers >= totalQuestions) {
                markLessonCompleted(userId, lessonId);
            }
        }

        return result != -1;
    }

    public boolean updateUserProgress(int userId, int lessonId, int points) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            db.beginTransaction();

            // Update total points
            ContentValues userValues = new ContentValues();
            userValues.put(COLUMN_PROGRESS, getUserProgress(userId) + points);
            db.update(TABLE_USERS, userValues,
                    COLUMN_ID + " = ?", new String[]{String.valueOf(userId)});

            // Mark lesson completed if not already
            if (!isLessonCompleted(userId, lessonId)) {
                ContentValues progressValues = new ContentValues();
                progressValues.put(COLUMN_USER_ID, userId);
                progressValues.put(COLUMN_LESSON_ID, lessonId);
                progressValues.put(COLUMN_IS_COMPLETED, 1);
                progressValues.put(COLUMN_COMPLETION_DATE, System.currentTimeMillis());
                db.insertWithOnConflict(TABLE_PROGRESS, null, progressValues, SQLiteDatabase.CONFLICT_REPLACE);
            }

            db.setTransactionSuccessful();
            return true;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error updating progress", e);
            return false;
        } finally {
            db.endTransaction();
        }
    }

    public boolean isLessonCompleted(int userId, int lessonId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT 1 FROM " + TABLE_PROGRESS +
                " WHERE " + COLUMN_USER_ID + " = ? AND " +
                COLUMN_LESSON_ID + " = ? AND " + COLUMN_IS_COMPLETED + " = 1 LIMIT 1";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId), String.valueOf(lessonId)});
        boolean completed = cursor.getCount() > 0;
        cursor.close();
        return completed;
    }

    // ========== Helper Methods ========== //
    private void initializeDefaultData(SQLiteDatabase db) {
        insertDefaultLessons(db);
        insertDefaultQuestions(db);
    }

    private void insertDefaultLessons(SQLiteDatabase db) {
        insertLesson(db, 1, "LinearLayout", "Arrange views vertically or horizontally",
                "Lesson content...", R.drawable.ic_layout, "Beginner");
        insertLesson(db, 2, "Buttons", "Handle user clicks and events",
                "Lesson content...", R.drawable.ic_button, "Beginner");
        insertLesson(db, 3, "TextViews", "Display and style text content",
                "Lesson content...", R.drawable.ic_text, "Beginner");
    }

    private void insertDefaultQuestions(SQLiteDatabase db) {
        // Lesson 1 questions
        insertQuestion(db, 1, 1, "LinearLayout can arrange views both vertically and horizontally.", 1);
        insertQuestion(db, 2, 1, "LinearLayout is more complex than ConstraintLayout.", 0);

        // Lesson 2 questions
        insertQuestion(db, 3, 2, "Buttons can only have text labels.", 0);
        insertQuestion(db, 4, 2, "You can set an onClick handler in XML.", 1);

        // Lesson 3 questions
        insertQuestion(db, 5, 3, "TextViews can display styled text.", 1);
        insertQuestion(db, 6, 3, "TextViews cannot be made clickable.", 0);
    }

    private void insertLesson(SQLiteDatabase db, int id, String title, String desc,String content, int iconRes, String difficulty) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, id);
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_DESCRIPTION, desc);
        values.put(COLUMN_CONTENT, content);
        values.put(COLUMN_ICON_RES, iconRes);
        values.put(COLUMN_DIFFICULTY, difficulty);
        db.insertWithOnConflict(TABLE_LESSONS, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    private void insertQuestion(SQLiteDatabase db, int id, int lessonId, String text, int correctAnswer) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, id);
        values.put(COLUMN_LESSON_ID, lessonId);
        values.put(COLUMN_QUESTION_TEXT, text);
        values.put(COLUMN_CORRECT_ANSWER, correctAnswer);
        db.insertWithOnConflict(TABLE_QUESTIONS, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    // Other existing methods remain unchanged...

    // ========== User Methods ========== //


    public boolean checkEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID},  // Changed from "user_id" to COLUMN_ID
                COLUMN_EMAIL + " = ?",
                new String[]{email},
                null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public boolean checkUserCredentials(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID},  // Changed from "user_id" to COLUMN_ID
                COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{email, password},
                null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public boolean markLessonCompleted(int userId, int lessonId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_LESSON_ID, lessonId);
        values.put("is_completed", 1);
        values.put("completion_date", System.currentTimeMillis());

        long result = db.insertWithOnConflict(TABLE_PROGRESS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        return result != -1;
    }

    // ========== Progress Tracking Methods ========== //




    public int getLessonScore(int userId, int lessonId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_PROGRESS +
                " WHERE " + COLUMN_USER_ID + " = ? AND " +
                COLUMN_LESSON_ID + " = ? AND " +
                COLUMN_IS_CORRECT + " = 1";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId), String.valueOf(lessonId)});
        cursor.moveToFirst();
        int score = cursor.getInt(0);
        cursor.close();
        return score;
    }

    public int getTotalScore(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_PROGRESS
                + " WHERE " + COLUMN_USER_ID + " = ? AND "
                + COLUMN_IS_CORRECT + " = 1";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
        cursor.moveToFirst();
        int totalScore = cursor.getInt(0);
        cursor.close();
        return totalScore;
    }


    public boolean deleteUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            // First get the user ID
            int userId = getUserIdByEmail(email);
            if (userId == -1) {
                return false; // User not found
            }

            // Begin transaction to ensure atomic operation
            db.beginTransaction();

            try {
                // 1. Delete user progress records
                db.delete(TABLE_PROGRESS,
                        COLUMN_USER_ID + " = ?",
                        new String[]{String.valueOf(userId)});

                // 2. Delete the user
                int userRows = db.delete(TABLE_USERS,
                        COLUMN_USER_ID + " = ?",
                        new String[]{String.valueOf(userId)});

                // Mark transaction as successful
                db.setTransactionSuccessful();

                return userRows > 0;
            } finally {
                // End transaction
                db.endTransaction();
            }
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error deleting user", e);
            return false;
        }
    }

    public int getUserProgress(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_PROGRESS},
                COLUMN_ID + " = ?",  // Using COLUMN_ID instead of "user_id"
                new String[]{String.valueOf(userId)},
                null, null, null);

        int progress = 0;
        if (cursor.moveToFirst()) {
            progress = cursor.getInt(0);
        }
        cursor.close();
        return progress;
    }


    public boolean updateUserCredentials(String oldEmail, String newEmail, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        try {
            if (!oldEmail.equals(newEmail)) {
                if (checkEmail(newEmail)) {
                    return false;
                }
                values.put(COLUMN_EMAIL, newEmail);
            }
            values.put(COLUMN_PASSWORD, newPassword);

            int rowsAffected = db.update(TABLE_USERS,
                    values,
                    COLUMN_EMAIL + " = ?",
                    new String[]{oldEmail});

            return rowsAffected > 0;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error updating user credentials", e);
            return false;
        }
    }

    // ========== Lesson Methods ========== //
    public List<Lesson> getAllLessons() {
        List<Lesson> lessonList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_LESSONS,
                new String[]{COLUMN_ID, COLUMN_TITLE, COLUMN_DESCRIPTION, COLUMN_ICON_RES},
                null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                Lesson lesson = new Lesson();
                lesson.setId(cursor.getInt(0));
                lesson.setTitle(cursor.getString(1));
                lesson.setDescription(cursor.getString(2));
                lesson.setIconResId(cursor.getInt(3));
                lessonList.add(lesson);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return lessonList;
    }


    public int getUserIdByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID},  // Changed from "user_id" to COLUMN_ID
                COLUMN_EMAIL + " = ?",
                new String[]{email},
                null, null, null);

        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        return userId;
    }
    // ========== Question Methods ========== //
    public List<Question> getQuestionsForLesson(int lessonId) {
        List<Question> questionList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_QUESTIONS,
                new String[]{COLUMN_QUESTION_ID, COLUMN_QUESTION_TEXT, COLUMN_CORRECT_ANSWER},
                COLUMN_LESSON_ID + " = ?",
                new String[]{String.valueOf(lessonId)},
                null, null, null);

        if (cursor.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(cursor.getInt(0));
                question.setLessonId(lessonId);
                question.setText(cursor.getString(1));
                question.setCorrectAnswer(cursor.getInt(2) == 1);
                questionList.add(question);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return questionList;
    }

    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_USERS,
                    new String[]{COLUMN_USER_ID, COLUMN_EMAIL, COLUMN_PASSWORD, COLUMN_PROGRESS},
                    null, null, null, null, COLUMN_PROGRESS + " DESC");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    User user = new User();
                    // Get column indices first
                    int idIndex = cursor.getColumnIndex(COLUMN_USER_ID);
                    int emailIndex = cursor.getColumnIndex(COLUMN_EMAIL);
                    int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);
                    int progressIndex = cursor.getColumnIndex(COLUMN_PROGRESS);

                    // Only set values if columns exist
                    if (idIndex != -1) user.setId(cursor.getInt(idIndex));
                    if (emailIndex != -1) user.setEmail(cursor.getString(emailIndex));
                    if (passwordIndex != -1) user.setPassword(cursor.getString(passwordIndex));
                    if (progressIndex != -1) user.setProgressPoints(cursor.getInt(progressIndex));

                    userList.add(user);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error getting all users", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return userList;
    }

    // ========== Leaderboard Methods ========== //
    public List<User> getLeaderboardData() {
        List<User> leaderboard = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to get top 10 users ordered by progress_points
        String query = "SELECT " + COLUMN_ID + ", " + COLUMN_EMAIL + ", " + COLUMN_PROGRESS +
                " FROM " + TABLE_USERS +
                " ORDER BY " + COLUMN_PROGRESS + " DESC LIMIT 10";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(cursor.getInt(0));
                user.setEmail(cursor.getString(1));
                user.setProgressPoints(cursor.getInt(2));
                leaderboard.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return leaderboard;
    }

    public int getLessonProgress(int userId, int lessonId) {
        SQLiteDatabase db = this.getReadableDatabase();

        // First check if lesson is completed
        Cursor progressCursor = db.query(TABLE_PROGRESS,
                new String[]{COLUMN_IS_COMPLETED},
                COLUMN_USER_ID + " = ? AND " + COLUMN_LESSON_ID + " = ?",
                new String[]{String.valueOf(userId), String.valueOf(lessonId)},
                null, null, null);

        boolean isCompleted = false;
        if (progressCursor.moveToFirst()) {
            isCompleted = progressCursor.getInt(0) == 1;
        }
        progressCursor.close();

        if (isCompleted) {
            return 100; // Lesson is fully completed
        }

        // Calculate progress based on correct answers
        int totalQuestions = getQuestionsForLesson(lessonId).size();
        if (totalQuestions == 0) {
            return 0; // No questions available
        }

        int correctAnswers = getLessonScore(userId, lessonId);
        return (correctAnswers * 100) / totalQuestions;
    }


}