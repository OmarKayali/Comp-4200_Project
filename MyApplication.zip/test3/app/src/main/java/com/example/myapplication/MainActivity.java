package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private SharedPreferences sharedPrefs;
    private String currentUserEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Initialize SharedPreferences early
        sharedPrefs = getSharedPreferences("user_prefs", MODE_PRIVATE);

        // 2. Check authentication
        if (!isUserAuthenticated()) {
            redirectToLogin();
            return;
        }

        setContentView(R.layout.activity_main);

        // 3. Initialize database and UI
        try {
            databaseHelper = new DatabaseHelper(this);
            initializeViews();
            setupUserInterface();
            setupNavigationButtons();
        } catch (Exception e) {
            Log.e("MainActivity", "Initialization failed", e);
            Toast.makeText(this, "App initialization error", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private boolean isUserAuthenticated() {
        currentUserEmail = getIntent().getStringExtra("USER_EMAIL");

        // Handle guest mode
        if ("guest".equals(currentUserEmail)) {
            return true;
        }

        boolean isLoggedIn = sharedPrefs.getBoolean("is_logged_in", false);
        boolean isRemembered = sharedPrefs.getBoolean("remember_me", false);

        if (currentUserEmail == null && isRemembered) {
            currentUserEmail = sharedPrefs.getString("email", null);
            return currentUserEmail != null;
        }

        return isLoggedIn || isRemembered;
    }

    private void redirectToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void initializeViews() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    private void setupUserInterface() {
        TextView tvWelcome = findViewById(R.id.tvWelcome);
        TextView tvProgress = findViewById(R.id.tvProgress);

        if ("guest".equals(currentUserEmail)) {
            tvWelcome.setText(R.string.guest_mode);
            tvProgress.setVisibility(View.GONE);
        } else {
            String welcomeText = String.format(getString(R.string.welcome_user),
                    currentUserEmail != null ? currentUserEmail : "User");
            tvWelcome.setText(welcomeText);
            updateProgressDisplay(tvProgress);
        }
    }

    private void updateProgressDisplay(TextView progressView) {
        if (currentUserEmail == null) {
            progressView.setVisibility(View.GONE);
            return;
        }

        int userId = databaseHelper.getUserIdByEmail(currentUserEmail);
        if (userId == -1) {
            progressView.setVisibility(View.GONE);
            return;
        }

        int progressPoints = databaseHelper.getUserProgress(userId);
        progressView.setText(String.format(getString(R.string.progress_points), progressPoints));
        progressView.setVisibility(View.VISIBLE);
    }

    private void setupNavigationButtons() {
        Button btnTutorials = findViewById(R.id.btnTutorials);
        Button btnLeaderboard = findViewById(R.id.btnLeaderboard);
        Button btnLogout = findViewById(R.id.btnLogout);
        Button btnDebugDB = findViewById(R.id.btnDebugDB); // Debug button

        // Regular navigation
        btnTutorials.setOnClickListener(v -> navigateTo(TutorialListActivity.class));
        btnLeaderboard.setOnClickListener(v -> navigateTo(LeaderboardActivity.class));
        btnLogout.setOnClickListener(v -> logoutUser());

        // DEBUG: Database verification button
        btnDebugDB.setOnClickListener(v -> {
            // 1. Print all lessons
            List<Lesson> lessons = databaseHelper.getAllLessons();
            Log.d("DEBUG_DB", "Total lessons: " + lessons.size());
            for (Lesson lesson : lessons) {
                Log.d("DEBUG_DB", "ID: " + lesson.getId() +
                        " | Title: " + lesson.getTitle());
            }

            // 2. Print database schema
            SQLiteDatabase db = databaseHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("PRAGMA table_info(lessons)", null);
            Log.d("DEBUG_DB", "Lessons table columns:");
            while (cursor.moveToNext()) {
                Log.d("DEBUG_DB", cursor.getString(1) + " - " + cursor.getString(2));
            }
            cursor.close();

            Toast.makeText(this, "Check Logcat for DB info", Toast.LENGTH_SHORT).show();
        });
    }

    private void navigateTo(Class<?> destination) {
        Intent intent = new Intent(this, destination);
        intent.putExtra("USER_EMAIL", currentUserEmail);
        startActivity(intent);
    }

    private void logoutUser() {
        sharedPrefs.edit()
                .putBoolean("is_logged_in", false)
                .putBoolean("remember_me", false)
                .remove("email")
                .apply();

        Toast.makeText(this, R.string.logged_out, Toast.LENGTH_SHORT).show();
        redirectToLogin();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem logoutItem = menu.findItem(R.id.action_logout);
        MenuItem profileItem = menu.findItem(R.id.action_profile);

        if (logoutItem != null && profileItem != null) {
            boolean isGuest = "guest".equals(currentUserEmail);
            logoutItem.setVisible(!isGuest);
            profileItem.setVisible(!isGuest);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_logout) {
            logoutUser();
            return true;
        } else if (itemId == R.id.action_profile) {
            navigateTo(ProfileActivity.class);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!"guest".equals(currentUserEmail)) {
            TextView tvProgress = findViewById(R.id.tvProgress);
            updateProgressDisplay(tvProgress);
        }
        invalidateOptionsMenu();
    }
}