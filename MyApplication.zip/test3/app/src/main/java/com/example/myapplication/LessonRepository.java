package com.example.myapplication;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

public class LessonRepository {
    private final DatabaseHelper dbHelper;
    private final AppExecutors executors;

    public LessonRepository(Application application) {
        this.dbHelper = new DatabaseHelper(application);
        this.executors = AppExecutors.getInstance();
    }

    public LiveData<Lesson> getLesson(int lessonId) {
        Log.d("LessonRepository", "Getting lesson with ID: " + lessonId);
        MutableLiveData<Lesson> liveData = new MutableLiveData<>();
        executors.diskIO().execute(() -> {
            Lesson lesson = dbHelper.getLesson(lessonId);
            Log.d("LessonRepository", "Retrieved lesson: " + (lesson != null ? lesson.getTitle() : "null"));
            executors.mainThread().execute(() -> liveData.setValue(lesson));
        });
        return liveData;
    }

    public LiveData<List<Question>> getQuestionsForLesson(int lessonId) {
        MutableLiveData<List<Question>> liveData = new MutableLiveData<>();
        executors.diskIO().execute(() -> {
            List<Question> questions = dbHelper.getQuestionsForLesson(lessonId);
            executors.mainThread().execute(() -> liveData.setValue(questions));
        });
        return liveData;
    }

    public LiveData<Boolean> updateUserProgress(int userId, int lessonId, int points) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        executors.diskIO().execute(() -> {
            try {
                // Update progress and mark lesson complete in a single transaction
                boolean success = dbHelper.updateUserProgress(userId, lessonId, points);

                // Only mark completed if this wasn't already done in the transaction
                if (success && !dbHelper.isLessonCompleted(userId, lessonId)) {
                    success = dbHelper.markLessonCompleted(userId, lessonId);
                }

                final boolean finalSuccess = success;
                executors.mainThread().execute(() -> result.setValue(finalSuccess));
            } catch (Exception e) {
                Log.e("LessonRepository", "Error updating progress", e);
                executors.mainThread().execute(() -> result.setValue(false));
            }
        });
        return result;
    }
}