package com.example.myapplication; // Should match manifest package

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LeaderboardActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private ListView listView;
    private LeaderboardAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        // Initialize views
        RecyclerView recyclerView = findViewById(R.id.rvLeaderboard);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Load leaderboard data
        loadLeaderboardData(recyclerView);
    }

    private void loadLeaderboardData(RecyclerView recyclerView) {
        List<User> leaderboardData = databaseHelper.getLeaderboardData();

        if (leaderboardData.isEmpty()) {
            // Show empty state if no data
            findViewById(R.id.tvEmptyLeaderboard).setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            // Setup adapter with data
            adapter = new LeaderboardAdapter(leaderboardData);
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}