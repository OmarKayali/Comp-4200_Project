package com.example.myapplication;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class LeaderboardActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private LeaderboardAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        // Initialize Toolbar with theme colors
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.colorPrimary));
        setSupportActionBar(toolbar);

        // Enable back button with proper tint
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.leaderboard_title);
            // Set navigation icon tint
            Drawable navIcon = toolbar.getNavigationIcon();
            if (navIcon != null) {
                navIcon.setTint(ContextCompat.getColor(this, R.color.white));
            }
        }

        // Initialize database
        databaseHelper = new DatabaseHelper(this);

        // Setup RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvLeaderboard);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load initial data
        loadLeaderboardData(recyclerView);
    }

    private void loadLeaderboardData(RecyclerView recyclerView) {
        List<User> leaderboardData = databaseHelper.getLeaderboardData();

        if (leaderboardData == null || leaderboardData.isEmpty()) {
            showEmptyState();
        } else {
            showLeaderboard(recyclerView, leaderboardData);
        }
    }

    private void showEmptyState() {
        findViewById(R.id.tvEmptyLeaderboard).setVisibility(View.VISIBLE);
        findViewById(R.id.rvLeaderboard).setVisibility(View.GONE);
        Toast.makeText(this, R.string.no_leaderboard_data, Toast.LENGTH_SHORT).show();
    }

    private void showLeaderboard(RecyclerView recyclerView, List<User> data) {
        adapter = new LeaderboardAdapter(data);
        recyclerView.setAdapter(adapter);
        findViewById(R.id.tvEmptyLeaderboard).setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_leaderboard, menu);

        // Apply tint to refresh icon
        MenuItem refreshItem = menu.findItem(R.id.action_refresh);
        if (refreshItem != null) {
            Drawable icon = refreshItem.getIcon();
            if (icon != null) {
                icon.setTint(ContextCompat.getColor(this, R.color.white));
                refreshItem.setIcon(icon);
            }
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        } else if (id == R.id.action_refresh) {
            refreshLeaderboard();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void refreshLeaderboard() {
        RecyclerView recyclerView = findViewById(R.id.rvLeaderboard);
        loadLeaderboardData(recyclerView);
        Toast.makeText(this, R.string.leaderboard_refreshed, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }
        super.onDestroy();
    }
}