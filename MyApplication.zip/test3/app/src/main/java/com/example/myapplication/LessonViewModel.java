package com.example.myapplication;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

// LessonViewModel.java
public class LessonViewModel extends AndroidViewModel {
    private final DatabaseHelper databaseHelper;
    private final MutableLiveData<Lesson> currentLesson = new MutableLiveData<>();
    private final MutableLiveData<List<Question>> questions = new MutableLiveData<>();

    public LessonViewModel(@NonNull Application application) {
        super(application);
        databaseHelper = new DatabaseHelper(application);
    }

    public LiveData<Lesson> getLesson(int lessonId) {
        new Thread(() -> {
            Lesson lesson = databaseHelper.getLesson(lessonId);
            currentLesson.postValue(lesson);
        }).start();
        return currentLesson;
    }

    public LiveData<List<Question>> getQuestionsForLesson(int lessonId) {
        new Thread(() -> {
            List<Question> questionList = databaseHelper.getQuestionsForLesson(lessonId);
            questions.postValue(questionList);
        }).start();
        return questions;
    }
    private final MutableLiveData<Integer> lessonProgress = new MutableLiveData<>();

    public LiveData<Integer> getLessonProgress(int userId, int lessonId) {
        new Thread(() -> {
            int progress = databaseHelper.getLessonProgress(userId, lessonId);
            lessonProgress.postValue(progress);
        }).start();
        return lessonProgress;
    }
    public LiveData<Boolean> updateUserProgress(int userId, int lessonId, int points) {
        MutableLiveData<Boolean> result = new MutableLiveData<>();
        new Thread(() -> {
            boolean success = databaseHelper.updateUserProgress(userId, lessonId, points);
            result.postValue(success);
        }).start();
        return result;
    }
}